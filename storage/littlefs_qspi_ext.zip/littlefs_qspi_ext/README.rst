.. zephyr:code-sample:: littlefs
   :name: LittleFS filesystem
   :relevant-api: file_system_api flash_area_api

   Use file system API over LittleFS.

Overview
********

This sample app demonstrates use of Zephyr's :ref:`file system API
<file_system_api>` over `littlefs`_, using file system with files that:
* count the number of times the system has booted
* holds binary pattern with properly incremented values in it
* Modified to have littlefs partition on external mx25 flash over qspi
* Modified to use static partitioning to specify the size

Sample documentation:
* https://docs.nordicsemi.com/bundle/ncs-2.9.1/page/zephyr/samples/subsys/fs/littlefs/README.html 
Modified with 
* https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/scripts/partition_manager/partition_manager.html and the note:
"Use the CONFIG_PM_PARTITION_REGION_LITTLEFS_EXTERNAL, CONFIG_PM_PARTITION_REGION_SETTINGS_STORAGE_EXTERNAL, and CONFIG_PM_PARTITION_REGION_NVS_STORAGE_EXTERNAL
 to specify that the relevant partition must be located in external flash memory. You must add a chosen entry for nordic,pm-ext-flash in your devicetree to make this option available. See tests/subsys/partition_manager for example configurations."



Requirements
************
Alternatively you can run this sample without using the pm_static.yml and the littlefs partition will still default to external flash due to the relevant configurations in prj.conf and app.overlay.
The default size will then be set to 6kB instead of 20kB which is set in the custom pm_static.yml


Flash memory device
-------------------

The partition labeled "storage" will be used for the file system; see
:ref:`flash_map_api`.  If that area does not already have a
compatible littlefs file system its contents will be replaced by an
empty file system.  You will see diagnostics like this::

   [00:00:00.010,192] <inf> littlefs: LittleFS version 2.0, disk version 2.0
   [00:00:00.010,559] <err> littlefs: Corrupted dir pair at 0 1
   [00:00:00.010,559] <wrn> littlefs: can't mount (LFS -84); formatting

The error and warning are normal for a new file system.

After the file system is mounted you'll also see::

   [00:00:00.182,434] <inf> littlefs: filesystem mounted!
   [00:00:00.867,034] <err> fs: failed get file or dir stat (-2)

This error is also normal for Zephyr not finding a file (the boot count,
in this case).



Building and Running
********************

Build for nrf52840dk and flash. Connect to a serial terminal. Expected output: ::
   
   I: littlefs partition at /lfs1
   I: LittleFS version 2.9, disk version 2.1
   I: FS at mx25r6435f@0:0x0 is 32 0x1000-byte blocks with 512 cycle
   I: sizes: rd 16 ; pr 16 ; ca 64 ; la 32
   E: WEST_TOPDIR/modules/fs/littlefs/lfs.c:1374: Corrupted dir pair at {0x0, 0x1}
   W: can't mount (LFS -84); formatting
   I: /lfs1 mounted
   I: Automount /lfs1 succeeded
   *** Booting nRF Connect SDK v2.9.0-nRF54H20-1-f7069dc707f3 ***
   *** Using Zephyr OS v3.7.99-d141a610109b ***
   Sample program to r/w files on littlefs
   Area 1 at 0x0 on mx25r6435f@0 for 131072 bytes
   /lfs1 automounted
   /lfs1: bsize = 16 ; frsize = 4096 ; blocks = 32 ; bfree = 30

   Listing dir /lfs1 ...
   /lfs1/boot_count read count:0 (bytes: 0)
   /lfs1/boot_count write new boot count 1: [wr:1]
   I: Test file: /lfs1/pattern.bin not found, create one!
   ------ FILE: /lfs1/pattern.bin ------
   01 55 55 55 55 55 55 55 02 55 55 55 55 55 55 55
   03 55 55 55 55 55 55 55 04 55 55 55 55 55 55 55
   05 55 55 55 55 55 55 55 06 55 55 55 55 55 55 55
   07 55 55 55 55 55 55 55 08 55 55 55 55 55 55 55
   09 55 55 55 55 55 55 55 0a 55 55 55 55 55 55 55
   0b 55 55 55 55 55 55 55 0c 55 55 55 55 55 55 55
   0d 55 55 55 55 55 55 55 0e 55 55 55 55 55 55 55
   0f 55 55 55 55 55 55 55 10 55 55 55 55 55 55 55
   11 55 55 55 55 55 55 55 12 55 55 55 55 55 55 55
   13 55 55 55 55 55 55 55 14 55 55 55 55 55 55 55
   15 55 55 55 55 55 55 55 16 55 55 55 55 55 55 55
   17 55 55 55 55 55 55 55 18 55 55 55 55 55 55 55
   19 55 55 55 55 55 55 55 1a 55 55 55 55 55 55 55
   1b 55 55 55 55 55 55 55 1c 55 55 55 55 55 55 55
   1d 55 55 55 55 55 55 55 1e 55 55 55 55 55 55 55
   1f 55 55 55 55 55 55 55 20 55 55 55 55 55 55 55
   21 55 55 55 55 55 55 55 22 55 55 55 55 55 55 55
   23 55 55 55 55 55 55 55 24 55 55 55 55 55 55 55
   25 55 55 55 55 55 55 55 26 55 55 55 55 55 55 55
   27 55 55 55 55 55 55 55 28 55 55 55 55 55 55 55
   29 55 55 55 55 55 55 55 2a 55 55 55 55 55 55 55
   2b 55 55 55 55 55 55 55 2c 55 55 55 55 55 55 55
   2d 55 55 55 55 55 55 55 2e 55 55 55 55 55 55 55
   2f 55 55 55 55 55 55 55 30 55 55 55 55 55 55 55
   31 55 55 55 55 55 55 55 32 55 55 55 55 55 55 55
   33 55 55 55 55 55 55 55 34 55 55 55 55 55 55 55
   35 55 55 55 55 55 55 55 36 55 55 55 55 55 55 55
   37 55 55 55 55 55 55 55 38 55 55 55 55 55 55 55
   39 55 55 55 55 55 55 55 3a 55 55 55 55 55 55 55
   3b 55 55 55 55 55 55 55 3c 55 55 55 55 55 55 55
   3d 55 55 55 55 55 55 55 3e 55 55 55 55 55 55 55
   3f 55 55 55 55 55 55 55 40 55 55 55 55 55 55 55

   41 55 55 55 55 55 55 55 42 55 55 55 55 55 55 55
   43 55 55 55 55 55 55 55 44 55 55 55 55 55 55 55
   45 55 aa 
   I: /lfs1 unmounted
   /lfs1 unmount: 0